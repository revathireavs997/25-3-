package com.charan.spring.hibernate.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.charan.spring.hibernate.pojo.User1;
import com.charan.spring.hibernate.service.AuthService;
 
@Component
@Controller
@RequestMapping("/user1")
public class RegisterCntrl {
	
    @Autowired
    private AuthService registerService; 
    
    // This will auto-inject the authentication service into the controller.
 
    
    
    public ModelAndView redirectregister()
    {
    	return new ModelAndView("registration");
    }
 
    
    // Checks if the user credentials are valid or not.
    
    @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
  
    //public ModelAndView registerUsr(@RequestParam("fname")String first_name,@RequestParam("lname")String last_name,@RequestParam("age")int age,@RequestParam("gender")String gender,@RequestParam("contact")int contact_number, @RequestParam("userid")String userid,@RequestParam("pwd")String password)
    public ModelAndView registerUsr(@RequestParam("fname")String first_name,@RequestParam("lname")String last_name,@RequestParam("age")int age,@RequestParam("gender")String gender,@RequestParam("contact")String contact_number, @RequestParam("userid")String userid,@RequestParam("pwd")String password)
    {
    	User1 u = new User1();
        
        u.setFirst_name(first_name);
        u.setLast_name(last_name);
        u.setAge(age);
        u.setGender(gender);
        u.setContact_number(contact_number);
        u.setUserid(userid);
        u.setPassword(password);
        
    	
		boolean isValid = registerService.registerUser(u);
		System.out.println("In the controller..");

		if(isValid)
		{
			
			return new ModelAndView("index" );	
		}
		else
		{
			System.out.println("register again!!!");
			return new ModelAndView("registration");
		}
 
      
    }


}
