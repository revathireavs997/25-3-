package com.charan.spring.hibernate.pojo;

public class SmartProduct {
	
	int id;
	
	String ProductRack,ProductName,ProductImage;
	int NoOfItems,DateOfManf,DateOfExpiry;

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public String getProductImage() {
		return ProductImage;
	}

	public void setProductImage(String productImage) {
		ProductImage = productImage;
	}

	public int getNoOfItems() {
		return NoOfItems;
	}

	public void setNoOfItems(int noOfItems) {
		NoOfItems = noOfItems;
	}

	public int getDateOfManf() {
		return DateOfManf;
	}

	public void setDateOfManf(int dateOfManf) {
		DateOfManf = dateOfManf;
	}

	public int getDateOfExpiry() {
		return DateOfExpiry;
	}

	public void setDateOfExpiry(int dateOfExpiry) {
		DateOfExpiry = dateOfExpiry;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductRack() {
		return ProductRack;
	}

	public void setProductRack(String productRack) {
		ProductRack = productRack;
	} 

}
